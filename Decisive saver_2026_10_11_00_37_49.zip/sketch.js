// ─────────────────────────────────────────────
//  PEACE & INK DOTS
//  Clic o ESPACIO = nueva imagen · tecla S = guardar PNG
// ─────────────────────────────────────────────

const W = 800;
const H = 800;
const NEON_PINK = [255, 20, 165];

// Paletas suaves para las manchas de acuarela (casi blanco y negro, con un toque de color)
const PALETAS = [
  [[200, 200, 208], [170, 172, 182], [228, 228, 228]],   // grises fríos
  [[210, 188, 208], [236, 205, 205], [182, 172, 202]],   // lavanda / rosado
  [[228, 204, 135], [190, 196, 202], [236, 232, 218]],   // ocre / gris
  [[215, 215, 205], [160, 160, 160], [240, 238, 232]]    // gris cálido
];

let seed;

function setup() {
  createCanvas(W, H);
  pixelDensity(1);
  noLoop();
  generar();
}

function generar() {
  seed = floor(random(1e9));
  randomSeed(seed);
  noiseSeed(seed);

  // Papel
  background(248, 245, 238);

  // 1. Fondo acuarela
  const paleta = random(PALETAS);
  const nManchas = floor(random(7, 12));
  for (let i = 0; i < nManchas; i++) {
    manchaAcuarela(random(W), random(H), random(150, 400), random(paleta));
  }

  // 2. Polka dots de tinta
  const paso = random(70, 115);
  const desfase = random() < 0.5; // a veces en cuadrícula, a veces escalonado
  let fila = 0;
  for (let y = -paso; y < H + paso; y += paso) {
    for (let x = -paso; x < W + paso; x += paso) {
      if (random() < 0.12) continue; // huecos aleatorios
      const px = x + (desfase && fila % 2 ? paso / 2 : 0) + random(-0.35, 0.35) * paso;
      const py = y + random(-0.35, 0.35) * paso;
      const r = paso * random(0.16, 0.36) * (0.6 + 0.9 * noise(px * 0.004, py * 0.004));
      puntoTinta(px, py, r);
    }
    fila++;
  }

  // 3. Símbolo de paz rosa neón (siempre presente)
  const cx = W / 2 + random(-40, 40);
  const cy = H / 2 + random(-40, 40);
  const r = random(220, 290);
  const conEstrellas = random() < 0.6;
  simboloPaz(cx, cy, r, conEstrellas);

  // 4. Grano de papel
  granoPapel();
}

// ── Mancha de acuarela: muchas capas translúcidas de un polígono deformado ──
function manchaAcuarela(cx, cy, r, c) {
  const n = 60;
  const base = [];
  for (let i = 0; i < n; i++) {
    const a = (TWO_PI * i) / n;
    const rr = r * (0.65 + 0.7 * noise(cos(a) + 10 + cx * 0.01, sin(a) + 10 + cy * 0.01));
    base.push({ a, r: rr });
  }
  noStroke();
  for (let l = 0; l < 30; l++) {
    fill(c[0], c[1], c[2], 6);
    beginShape();
    for (const v of base) {
      const rr = v.r * (1 + random(-0.1, 0.1));
      vertex(cx + cos(v.a) * rr, cy + sin(v.a) * rr);
    }
    endShape(CLOSE);
  }
}

// ── Punto de tinta que se "sangra" en el papel ──
function puntoTinta(x, y, r) {
  noStroke();

  // halo difuso
  for (let i = 0; i < 10; i++) {
    fill(20, 20, 30, 5);
    circle(x, y, r * 2 * (1.25 + i * 0.12));
  }

  // núcleo irregular
  fill(5, 5, 10, 235);
  beginShape();
  const n = 70;
  for (let i = 0; i < n; i++) {
    const a = (TWO_PI * i) / n;
    const rr = r * (i % 2 ? random(0.85, 1.15) : random(0.95, 1.3));
    vertex(x + cos(a) * rr, y + sin(a) * rr);
  }
  endShape(CLOSE);

  // fibras radiales
  stroke(5, 5, 10, 110);
  strokeWeight(0.8);
  for (let i = 0; i < 90; i++) {
    const a = random(TWO_PI);
    const d1 = r * random(0.7, 1.0);
    const d2 = r * random(1.05, 1.5);
    line(x + cos(a) * d1, y + sin(a) * d1, x + cos(a) * d2, y + sin(a) * d2);
  }

  // salpicaduras finas
  noStroke();
  fill(5, 5, 10, 150);
  for (let i = 0; i < 50; i++) {
    const a = random(TWO_PI);
    const d = r * (1 + abs(randomGaussian()) * 0.35);
    circle(x + cos(a) * d, y + sin(a) * d, random(1, 3));
  }
}

// ── Símbolo de paz con brillo neón ──
function simboloPaz(cx, cy, r, conEstrellas) {
  const grosor = W * 0.026;
  const d = r * cos(QUARTER_PI);

  const ctx = drawingContext;
  ctx.shadowColor = color(...NEON_PINK).toString();

  // dos pasadas para que el brillo sea más intenso
  for (const blur of [40, 14]) {
    ctx.shadowBlur = blur;
    stroke(...NEON_PINK);
    strokeWeight(grosor);
    strokeCap(ROUND);
    noFill();
    circle(cx, cy, r * 2);
    line(cx, cy - r, cx, cy + r);
    line(cx, cy, cx - d, cy + d);
    line(cx, cy, cx + d, cy + d);

    if (conEstrellas) {
      noStroke();
      fill(...NEON_PINK);
      const n = 16;
      for (let i = 0; i < n; i++) {
        const a = (TWO_PI * i) / n - HALF_PI;
        estrella(cx + cos(a) * (r + 55), cy + sin(a) * (r + 55), 10, 24, 5);
      }
    }
  }
  ctx.shadowBlur = 0;
}

function estrella(x, y, r1, r2, puntas) {
  const paso = TWO_PI / puntas;
  beginShape();
  for (let a = -HALF_PI; a < TWO_PI - HALF_PI; a += paso) {
    vertex(x + cos(a) * r2, y + sin(a) * r2);
    vertex(x + cos(a + paso / 2) * r1, y + sin(a + paso / 2) * r1);
  }
  endShape(CLOSE);
}

// ── Textura de papel ──
function granoPapel() {
  noStroke();
  for (let i = 0; i < 25000; i++) {
    fill(random() < 0.5 ? 0 : 255, 14);
    rect(random(W), random(H), 1, 1);
  }
}

function mousePressed() {
  if (mouseX >= 0 && mouseX <= W && mouseY >= 0 && mouseY <= H) generar();
}

function keyPressed() {
  if (key === ' ') generar();
  if (key === 's' || key === 'S') saveCanvas('paz-tinta-' + seed, 'png');
}